﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W09_Class
{
    public partial class Main : Form
    {
        public Main()
        {
            InitializeComponent();
        }

        private void addToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 add = new Form2();
            add.MdiParent = this;           
            add.Show();
        }

        private void logOutToolStripMenuItem_Click(object sender, EventArgs e)
        { 
            User.username = "";
            User.password = "";

            this.Close();
            Form1 logout= new Form1();
            logout.Show();
            this.Hide();
            
        }

        private void Main_Load(object sender, EventArgs e)
        {
            lb_user.Text = User.username;
            lb_datetime.Text = DateTime.Now.ToString("ddd, dd-MM-yyyy HH:mm:ss");
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            lb_datetime.Text = DateTime.Now.ToString("ddd, dd-MM-yyyy HH:mm:ss");
        }
    }
}
