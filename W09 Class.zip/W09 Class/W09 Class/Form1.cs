﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W09_Class
{//TALITHA 0706022310019
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
            List.user.Add("admin");
            List.pass.Add("admin");
        }

        private void btn_login_Click(object sender, EventArgs e)
        {
            bool exit = true;
            for (int i = 0; i < List.user.Count; i++)
            {
                if (List.user[i] == tb_user.Text && List.pass[i] == tb_pass.Text)
                {
                    MessageBox.Show("Login Success!");
                    exit = false;
                } 
            }

            if (exit == true)
            {
                MessageBox.Show("User or Pass is wrong");
                tb_user.Text = "";
                tb_pass.Text = "";
            }

            else
            {
                User.username = tb_user.Text;
                User.password = tb_pass.Text;

                Main main = new Main();
                main.Show();
                this.Hide();
            }

        }
    }
}
