﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace W09_Class
{
    public partial class Form2 : Form
    {
        public Form2()
        {
            InitializeComponent();
        }

        private void btn_add_Click(object sender, EventArgs e)
        {
            bool exit = true;
            if (tb_pass2.Text != tb_confirm.Text )
            {
                MessageBox.Show("Confirm Pass not the same");
            }

            for (int i = 0; i < List.user.Count; i++)
            {
                if (List.user[i] == tb_user2.Text)
                {
                    MessageBox.Show("Username already exists! ");
                    exit = false;
                }
            }

            if (exit == true)
            {
                List.user.Add(tb_user2.Text);
                List.pass.Add(tb_pass2.Text);
                MessageBox.Show("User created! ");
;
                tb_user2.Text = "";
                tb_pass2.Text = "";
                tb_confirm.Text = "";
            }

             
        }
    }
}
