﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace W09_Class
{
    internal class List
    {

        public static List<string> user = new List<string>();
        public static List<string> pass = new List<string>();

    }
}
